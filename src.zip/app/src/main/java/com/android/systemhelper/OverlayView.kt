package com.android.systemhelper
import android.content.Context
import android.graphics.*
import android.view.View

class OverlayView(c: Context) : View(c) {
    private val paintBox = Paint().apply { color = 0xFF00FF00.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val paintText = Paint().apply { color = 0xFF00FF00.toInt(); textSize = 36f; isAntiAlias = true; typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!Config.espEnable || !Config.authed) return
        for (t in Detector.latest) {
            canvas.drawRect(t.x.toFloat(), t.y.toFloat(), (t.x + t.w).toFloat(), (t.y + t.h).toFloat(), paintBox)
            val textY = if (t.y - 10f > 40f) t.y - 10f else t.y + 40f
            canvas.drawText("${t.health}%", t.x.toFloat(), textY, paintText)
        }
    }
}