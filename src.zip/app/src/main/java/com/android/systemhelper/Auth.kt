package com.android.systemhelper
object Auth {
    fun fnv1a(s: String): Long {
        var h = -3750763034362895579L
        for (c in s) { h = h xor c.code.toLong(); h *= 1099511628211L }
        return h
    }
    fun verify(input: String): Boolean {
        if (fnv1a(input) == fnv1a("114514")) { Config.authed = true; return true }
        return false
    }
}